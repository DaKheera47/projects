from fuzzywuzzy import fuzz

with open("threeLetterWords.txt", "r") as f:
    threeWords = f.read().split("\n")

with open("fourLetterWords.txt", "r") as f:
    fourWords = f.read().split(" ")

with open("links.txt", "r") as f:
    links = f.read().split("\n")

for link in list(set(links)):
    code = link[-12:]
    start = code[:3]
    mid = code[4:8]
    end = code[-3:]

    for word in threeWords:
        # ratio = fuzz.ratio(mid.lower(), word.lower())
        if word in mid and word != "":
            with open("vibe.txt", "a+") as f:
                f.write(f"{word} + {mid}\n")
                # f.write(f"{ratio} + {word} + {mid}\n")


# Str1 = "eating"
# Str2 = "eatn"
# Ratio = fuzz.ratio(Str1.lower(), Str2.lower())
# print(Ratio)
