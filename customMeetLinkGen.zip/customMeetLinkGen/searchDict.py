with open("threeLetterWords.txt", "r") as f:
    threeWords = f.read().split("\n")

with open("customThreeLetterWords.txt", "r") as f:
    customThreeWords = f.read().split("\n")

with open("customFourLetterWords.txt", "r") as f:
    customFourWords = f.read().split("\n")

with open("fourLetterWords.txt", "r") as f:
    fourWords = f.read().split(" ")

with open("links.txt", "r") as f:
    links = f.read().split("\n")


with open("out.txt", "a+") as f:
    f.write(f"Custom 3 letter combos\n")

for link in list(set(links)):
    code = link[-12:]
    start = code[:3]
    mid = code[4:8]
    end = code[-3:]

    for word in list(set(customThreeWords)):
        if word == start or word == end:
            with open("out.txt", "a+") as f:
                f.write(f"{link} -- custom 3 letter combo\n")


# with open("out.txt", "a+") as f:
#     f.write(f"Start\n")

# for link in list(set(links)):
#     code = link[-12:]
#     start = code[:3]
#     mid = code[4:8]
#     end = code[-3:]

#     for word in list(set(threeWords)):
#         if word == start:
#             with open("out.txt", "a+") as f:
#                 f.write(f"{link} -- Start\n")

# with open("out.txt", "a+") as f:
#     f.write(f"Ends\n")

# for link in list(set(links)):
#     code = link[-12:]
#     start = code[:3]
#     mid = code[4:8]
#     end = code[-3:]

#     for word in list(set(threeWords)):
#         if word == end:
#             with open("out.txt", "a+") as f:
#                 f.write(f"{link} -- End\n")

with open("out.txt", "a+") as f:
    f.write(f"\ncustomFourWords\n")

for link in list(set(links)):
    code = link[-12:]
    start = code[:3]
    mid = code[4:8]
    end = code[-3:]

    for word in list(set(customFourWords)):
        if word == mid:
            with open("out.txt", "a+") as f:
                f.write(f"{link} -- customFourWords\n")

# with open("out.txt", "a+") as f:
#     f.write(f"Middle\n")

# for link in list(set(links)):
#     code = link[-12:]
#     start = code[:3]
#     mid = code[4:8]
#     end = code[-3:]

#     for word in list(set(fourWords)):
#         if word == mid:
#             with open("out.txt", "a+") as f:
#                 f.write(f"{link} -- Middle\n")
