import pyautogui as pag
import time
import win32clipboard

DELAY = 0.45


def getCopied():
    # delay is required as a measure to prevent `ctrl + x` mixing with the hotkey entered
    time.sleep(DELAY)

    win32clipboard.OpenClipboard()
    try:
        # getting current data for resetting clipboard later
        prevClip = win32clipboard.GetClipboardData()
    except TypeError:
        win32clipboard.SetClipboardData(win32clipboard.CF_UNICODETEXT, " ")
    win32clipboard.CloseClipboard()

    # get currently selected text
    pag.hotkey("ctrl", "x")
    time.sleep(0.3)

    # get clipboard data
    win32clipboard.OpenClipboard()
    data = win32clipboard.GetClipboardData()

    # resetting clipboard data to previous content
    try:
        win32clipboard.SetClipboardData(
            win32clipboard.CF_UNICODETEXT, prevClip)
    except:
        print("line 36: prevClip set error")

    win32clipboard.CloseClipboard()
    return data


time.sleep(5)

possibleThreeLetterCombos = [
    "kid",
    "ali",
    "aam",
    "pro",
    "dak",
    "mic",
    "usb",
    "kbm",
    "you",
    "fuc",
    "kal",
    "aaj",
    "tum",
    "hum",
    "yes",
    "aby",
    "emn",
    "pnp",
    "ynw",
    "sex",
    "sax",
    "mom",
    "fit",
    "abs",
    "car",
    "bus",
    "sin",
    "cos",
    "tan",
    "doe",
    "ego",
    "sed",
    "sad",
    "fax",
    "omg",
    "gym",
    "eye",
    "die",
]

possibleMiddles = [
    "zain",
    "moiz",
    "aamz",
    "abby",
    "eman",
    "mano",
    "boot",
    "dora",
    "saju",
    "meet",
    "dani",
    "shrz",
    "dhoe",
    "auto",
    "link",
    "meet",
    "help",
    "posh",
    "clnt",
    "deer",
    "zayn",
    "snex",
    "smex",
    "xmas",
    "like",
    "time",
    "edge",
    "risk",
    "seen",
    "type",
    "warm",
    "zrls",
    "arrn",
    "aree",
    "akbr",
    "wind",
    "soon",
    "fssi",
    "ammr",
    "amar",
    "anar",
    "pixz",
    "pikz",
    "picx",
    "mein",
    "abas",
]

possibleWholeLinks = [
    "git-pull-all",
    "mai-gari-tum",
    "luv-aree-sha",
    "ali-khan-man",
    "oun-camz-now",
    "die-hell-now",
    "zip-open-now",
    "yes-bish-you",
    "omg-loif-sed",
    "pnp-wrld-all",
    "cos-sine-tan",
    "jaw-moiz-bal",
    "bal-moiz-jaw",
    "tan-sine-cos",
    "dak-amar-bus",
    "bus-mayn-pig",
    "bus-amar-dak",
    "car-gear-abs",
    "bts-army-bad",
    "you-shag-mum",
    "gud-blow-job",
    "lun-gand-you",
    "new-link-gen",
    "emn-dani-luv",
    "you-moma-fat"
]

pag.PAUSE = 0.3
pag.press("winleft")
pag.write("edge")
pag.press("enter")
time.sleep(3)

while True:
# for i in range(1, 2):
    pag.hotkey("alt", "d")
    pag.write("https://meet.google.com/new", interval=0)
    pag.press("enter")

    time.sleep(7)

    pag.hotkey("alt", "d")
    link = getCopied()
    # link = "https://meet.google.com/kid-qeum-zoc"

    # code = link[-12:]
    # start = code[:3]
    # mid = code[4:8]
    # end = code[-3:]

    with open("links.txt", "a+") as file:
        file.write(f"{link}\n")

    # for prefix in possibleThreeLetterCombos:
    #     if start == prefix or end == prefix:
    #         with open("success.txt", "a+") as file:
    #             file.write(f"{link}\n")

    # for middle in possibleMiddles:
    #     if mid == middle:
    #         with open("success.txt", "a+") as file:
    #             file.write(f"{link}\n")

    # for wholeLink in possibleWholeLinks:
    #     if code == wholeLink:
    #         with open("success.txt", "a+") as file:
    #             file.write(f"{link}\n")
