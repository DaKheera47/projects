import pyautogui as pag
print(pag.position())
