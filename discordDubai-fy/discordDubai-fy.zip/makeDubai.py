import pyautogui as pag
from helpers import findImageTimeout, phraseInString, clear
import pyperclip
import time

pag.PAUSE = 0.2
timeStarted = time.time()
counter = 0

while True:
    counter += 1
    pag.click(findImageTimeout("vcName.png"))
    pag.click(findImageTimeout("voiceConnected.png"))
    time.sleep(1)
    pag.moveTo(x=326, y=839)
    pag.dragTo(x=115, y=550, duration=0.5)
    pag.hotkey("ctrl", "c")

    if phraseInString("dubai", pyperclip.paste()):
        break
    else:
        clear()
        pag.click(findImageTimeout("disconnect.png"))
        print(f"""
    Total duration of session: {round(time.time() - timeStarted, 3)}s
    Time per join: {round((time.time() - timeStarted) / counter, 3)}s
    Total attempts: {counter}
""")
